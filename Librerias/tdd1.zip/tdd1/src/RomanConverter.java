import java.lang.reflect.Array;
import java.util.HashMap;

public class RomanConverter {
    public String convert(int aNumber) {
        int[] digits = {1, 5, 10, 50, 100, 500, 1000};
        String[] roman = {"I", "V", "X", "L", "C", "D", "M"};

        HashMap<Integer, String> arabicToRoman = new HashMap<>();
        arabicToRoman.put(1, "I");
        arabicToRoman.put(5, "V");
        arabicToRoman.put(10, "X");
        arabicToRoman.put(50, "L");
        arabicToRoman.put(100, "C");
        arabicToRoman.put(500, "D");
        arabicToRoman.put(1000, "M");

        String result = "";

        if (aNumber >= 900){
            result = "CM" + writeUntil399(aNumber - 900);
        }else {
            if (aNumber >= 500) {
                result = "D" + writeUntil399(aNumber - 500);
            } else {
                if (aNumber >= 400){
                    result = "CD" + writeUntil399(aNumber - 400);
                } else {
                    result = writeUntil399(aNumber);
                }
            }
        }

        return result;
    }

    private  String writeUntil399(int aNumber){
        String result = "";

        if (aNumber >= 100){
            int centenas = aNumber / 100;
            result = repeatSymbol(centenas, "C");
            result = result + writeUntil99(aNumber - (100 * centenas));
        }else {
            result = writeUntil99(aNumber);
        }
        return result;
    }



    private String writeUntil99(int aNumber) {
        String result;
        if (aNumber >= 90){
            result = "XC" + writeUntil9(aNumber - 90);
        }else {
            if (aNumber >= 50) {
                result = "L" + writeUntil39(aNumber - 50);
            } else {
                if (aNumber >= 40) {
                    result = "XL" + writeUntil9(aNumber - 40);
                } else {
                    result = writeUntil39(aNumber);
                }
            }
        }

        return result;
    }

    private String writeUntil39(int aNumber){
        String result = "";

        int decenas = aNumber / 10;

        result = repeatSymbol(decenas, "X");
        return result + writeUntil9(aNumber - (decenas * 10));
    }

    private String writeUntil9(int aNumber) {
        String result;
        if (aNumber == 9) {
            result = "IX";
        } else {
            if (aNumber >= 5) {
                result = XXX(aNumber - 5, "V");
            } else {
                if (aNumber == 4) {
                    result = "IV";
                } else {
                    result = XXX(aNumber, "");
                }
            }
        }
        return result;
    }

    private String XXX(int aNumber, String s) {
        String result;
        return s +  repeatSymbol(aNumber, "I");
    }

    private String repeatSymbol(int aNumber, String symbol) {
        String result = "";
        for (int i = 0; i < aNumber; i++) {
            result += symbol;
        }

        return result;
    }
}
