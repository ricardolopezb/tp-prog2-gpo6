import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class RomanConverterTest {

    RomanConverter converter;
    @Before
    public void setUp(){
        converter = new RomanConverter();
    }

    @Test
    public void test01_1DebeSerI(){
        assertEquals("I", converter.convert(1));
    }

    @Test
    public void test02_2DebeSerII(){
        assertEquals("II", converter.convert(2));
    }

    @Test
    public void test03_3DebeSerIII(){
        assertEquals("III", converter.convert(3));
    }

    @Test
    public void test04_4DebeSerIV(){
        assertEquals("IV", converter.convert(4));
    }

    @Test
    public void test05_5DebeSerV(){
        assertEquals("V", converter.convert(5));
    }

    @Test
    public void test06_6DebeSerVI(){
        assertEquals("VI", converter.convert(6));
    }

    @Test
    public void test07_7DebeSerVII(){
        assertEquals("VII", converter.convert(7));
    }

    @Test
    public void test08_8DebeSerVIII(){
        assertEquals("VIII", converter.convert(8));
    }

    @Test
    public void test09_9DebeSerIX(){
        assertEquals("IX", converter.convert(9));
    }

    @Test
    public void test10_10DebeSerX(){
        assertEquals("X", converter.convert(10));
    }

    @Test
    public void test11_11DebeSerXI(){
        assertEquals("XI", converter.convert(11));
    }

    @Test
    public void test12_12DebeSerXII(){
        assertEquals("XII", converter.convert(12));
    }

    @Test
    public void test13_13DebeSerXIII(){
        assertEquals("XIII", converter.convert(13));
    }

    @Test
    public void test14_14DebeSerXIV(){
        assertEquals("XIV", converter.convert(14));
    }
    @Test
    public void test15_15DebeSerXIV(){
        assertEquals("XV", converter.convert(15));
    }
    @Test
    public void test16_16DebeSerXIV(){
        assertEquals("XVI", converter.convert(16));
    }

    @Test
    public void test17_17DebeSerXIV(){
        assertEquals("XVII", converter.convert(17));
    }

    @Test
    public void test18_18DebeSerXVIII(){
        assertEquals("XVIII", converter.convert(18));
    }

    @Test
    public void test19_19DebeSerXIX(){
        assertEquals("XIX", converter.convert(19));
    }

    @Test
    public void test20_20DebeSerXX(){
        assertEquals("XX", converter.convert(20));
    }
    @Test
    public void test21_21DebeSerXX(){
        assertEquals("XXI", converter.convert(21));
    }

    @Test
    public void test30_30DebeSerXXX(){
        assertEquals("XXX", converter.convert(30));
    }

    @Test
    public void test39_39DebeSerXXXIX(){
        assertEquals("XXXIX", converter.convert(39));
    }

    @Test
    public void test40_40DebeSerXL(){
        assertEquals("XL", converter.convert(40));
    }

    @Test
    public void test53_53DebeSerLIII(){
        assertEquals("LIII", converter.convert(53));
    }

    @Test
    public void test63_40DebeSerLXIII(){
        assertEquals("LXIII", converter.convert(63));
    }

    @Test
    public void test_89DebeSerLXXXIX(){
        assertEquals("LXXXIX", converter.convert(89));
    }

    @Test
    public void test_90DebeSerXC(){
        assertEquals("XC", converter.convert(90));
    }

    @Test
    public void test_399DebeSerCCCXCIX(){
        assertEquals("CCCXCIX", converter.convert(399));
    }

    @Test
    public void test_400DebeSerCD(){
        assertEquals("CD", converter.convert(400));
    }

    @Test
    public void test_899DebeSerDCCCXCIX(){
        assertEquals("DCCCXCIX", converter.convert(899));
    }

    @Test
    public void test_999DebeSerCMXCIX(){
        assertEquals("CMXCIX", converter.convert(999));
    }

}
